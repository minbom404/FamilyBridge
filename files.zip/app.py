"""
FamilyBridge Backend API
Flask + SQLite — no external dependencies beyond PyJWT & Flask
"""

import sqlite3
import hashlib
import hmac
import os
import re
import json
from datetime import datetime, timedelta, timezone
from functools import wraps
from flask import Flask, request, jsonify, g

import jwt as pyjwt

# ─────────────────────────────────────────────
app = Flask(__name__)
SECRET_KEY = os.environ.get("SECRET_KEY", "familybridge-secret-dev-key-2025")
DB_PATH = os.path.join(os.path.dirname(__file__), "familybridge.db")

# ─────────────────────────────────────────────
# CORS helper — manual since flask-cors unavailable
# ─────────────────────────────────────────────
@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
    return response

@app.route("/", defaults={"path": ""}, methods=["OPTIONS"])
@app.route("/<path:path>", methods=["OPTIONS"])
def options_handler(path=""):
    return jsonify({}), 200

# ─────────────────────────────────────────────
# DATABASE
# ─────────────────────────────────────────────
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exc=None):
    db = g.pop("db", None)
    if db:
        db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name  TEXT NOT NULL,
            last_name   TEXT NOT NULL,
            email       TEXT NOT NULL UNIQUE,
            password    TEXT NOT NULL,
            role        TEXT NOT NULL DEFAULT 'Parent / Guardian',
            created_at  TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS family_members (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            name         TEXT NOT NULL,
            age          INTEGER,
            relationship TEXT NOT NULL,
            email        TEXT,
            created_at   TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS mentors (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            name         TEXT NOT NULL,
            specialty    TEXT NOT NULL,
            bio          TEXT,
            years_exp    INTEGER,
            rating       REAL DEFAULT 4.8,
            sessions     INTEGER DEFAULT 0,
            emoji        TEXT DEFAULT '🧑‍⚕️'
        );

        CREATE TABLE IF NOT EXISTS meetings (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            mentor_id    INTEGER REFERENCES mentors(id),
            session_type TEXT NOT NULL,
            date         TEXT NOT NULL,
            time         TEXT NOT NULL,
            notes        TEXT,
            status       TEXT NOT NULL DEFAULT 'scheduled',
            created_at   TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS lessons (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            title        TEXT NOT NULL,
            description  TEXT,
            duration_min INTEGER DEFAULT 45,
            level        TEXT DEFAULT 'Beginner',
            emoji        TEXT DEFAULT '📖',
            module_num   INTEGER
        );

        CREATE TABLE IF NOT EXISTS user_lessons (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            lesson_id    INTEGER NOT NULL REFERENCES lessons(id),
            members_tag  TEXT DEFAULT 'Whole Family',
            date         TEXT,
            time_slot    TEXT,
            progress     INTEGER DEFAULT 0,
            status       TEXT DEFAULT 'scheduled',
            created_at   TEXT NOT NULL DEFAULT (datetime('now'))
        );
    """)

    # Seed mentors if empty
    row = db.execute("SELECT COUNT(*) as c FROM mentors").fetchone()
    if row["c"] == 0:
        db.executemany(
            "INSERT INTO mentors (name,specialty,bio,years_exp,rating,sessions,emoji) VALUES (?,?,?,?,?,?,?)",
            [
                ("Dr. Layla Osman",
                 "Child & Family Psychologist",
                 "Specializes in parent-child attachment theory and adolescent communication. 14 years of clinical experience.",
                 14, 4.9, 380, "👩‍⚕️"),
                ("Dr. Marcus Chen",
                 "Family Systems Therapist",
                 "Expert in family system dynamics and intergenerational patterns. Uses evidence-based CBT and narrative therapy.",
                 10, 4.8, 290, "👨‍⚕️"),
                ("Dr. Amina Faruki",
                 "Developmental Psychologist",
                 "Focuses on childhood development stages and helping parents adapt their approach as children grow.",
                 8, 4.9, 220, "👩‍🏫"),
            ]
        )

    # Seed lessons if empty
    row = db.execute("SELECT COUNT(*) as c FROM lessons").fetchone()
    if row["c"] == 0:
        db.executemany(
            "INSERT INTO lessons (title,description,duration_min,level,emoji,module_num) VALUES (?,?,?,?,?,?)",
            [
                ("Active Listening Foundations",
                 "Learn how to truly hear your child's needs and feelings without judgment.",
                 45, "Beginner", "👂", 1),
                ("Emotional Vocabulary Building",
                 "Help your family name and express emotions in healthy, constructive ways.",
                 50, "Beginner", "💬", 2),
                ("Setting Healthy Boundaries",
                 "Create loving boundaries that foster respect and independence in your home.",
                 60, "Intermediate", "🌿", 3),
                ("Conflict Resolution Together",
                 "Turn disagreements into growth opportunities using proven techniques.",
                 55, "Intermediate", "🤝", 4),
                ("Love Languages in Families",
                 "Discover how each family member gives and receives love differently.",
                 40, "Beginner", "💛", 5),
                ("Screen Time & Quality Time Balance",
                 "Practical strategies for reclaiming meaningful family time in a digital world.",
                 50, "Intermediate", "📱", 6),
                ("Praise & Positive Reinforcement",
                 "Master the art of encouragement that builds confidence and intrinsic motivation.",
                 45, "Beginner", "⭐", 7),
                ("Navigating Teenage Independence",
                 "Support your teen's growing autonomy while maintaining a close connection.",
                 65, "Advanced", "🌱", 8),
            ]
        )

    db.commit()
    db.close()
    print("✅ Database initialized")


# ─────────────────────────────────────────────
# AUTH HELPERS
# ─────────────────────────────────────────────
def hash_password(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()

def make_token(user_id: int, email: str) -> str:
    payload = {
        "sub": user_id,
        "email": email,
        "exp": datetime.now(timezone.utc) + timedelta(days=7),
    }
    return pyjwt.encode(payload, SECRET_KEY, algorithm="HS256")

def require_auth(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing token"}), 401
        token = auth.split(" ", 1)[1]
        try:
            payload = pyjwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        except pyjwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired"}), 401
        except pyjwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401
        g.user_id = payload["sub"]
        g.user_email = payload["email"]
        return f(*args, **kwargs)
    return wrapper

def row_to_dict(row):
    return dict(row) if row else None

def rows_to_list(rows):
    return [dict(r) for r in rows]


# ─────────────────────────────────────────────
# AUTH ROUTES
# ─────────────────────────────────────────────
@app.route("/api/auth/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    first_name = (data.get("first_name") or "").strip()
    last_name  = (data.get("last_name") or "").strip()
    email      = (data.get("email") or "").strip().lower()
    password   = data.get("password") or ""
    role       = (data.get("role") or "Parent / Guardian").strip()

    errors = {}
    if not first_name: errors["first_name"] = "Required"
    if not last_name:  errors["last_name"]  = "Required"
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email): errors["email"] = "Invalid email"
    if len(password) < 6: errors["password"] = "Minimum 6 characters"
    if errors: return jsonify({"errors": errors}), 422

    db = get_db()
    if db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone():
        return jsonify({"errors": {"email": "Already registered"}}), 409

    db.execute(
        "INSERT INTO users (first_name,last_name,email,password,role) VALUES (?,?,?,?,?)",
        (first_name, last_name, email, hash_password(password), role)
    )
    db.commit()
    user = row_to_dict(db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone())
    token = make_token(user["id"], user["email"])
    user.pop("password", None)
    return jsonify({"token": token, "user": user}), 201


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    email    = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    db = get_db()
    user = row_to_dict(db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone())
    if not user or user["password"] != hash_password(password):
        return jsonify({"error": "Invalid email or password"}), 401

    token = make_token(user["id"], user["email"])
    user.pop("password", None)
    return jsonify({"token": token, "user": user})


@app.route("/api/auth/me", methods=["GET"])
@require_auth
def me():
    db = get_db()
    user = row_to_dict(db.execute("SELECT * FROM users WHERE id=?", (g.user_id,)).fetchone())
    if not user:
        return jsonify({"error": "User not found"}), 404
    user.pop("password", None)
    return jsonify(user)


# ─────────────────────────────────────────────
# MENTORS
# ─────────────────────────────────────────────
@app.route("/api/mentors", methods=["GET"])
def get_mentors():
    db = get_db()
    return jsonify(rows_to_list(db.execute("SELECT * FROM mentors").fetchall()))


# ─────────────────────────────────────────────
# MEETINGS
# ─────────────────────────────────────────────
@app.route("/api/meetings", methods=["GET"])
@require_auth
def get_meetings():
    db = get_db()
    rows = db.execute("""
        SELECT m.*, mt.name AS mentor_name, mt.emoji AS mentor_emoji
        FROM meetings m
        LEFT JOIN mentors mt ON mt.id = m.mentor_id
        WHERE m.user_id = ?
        ORDER BY m.date, m.time
    """, (g.user_id,)).fetchall()
    return jsonify(rows_to_list(rows))


@app.route("/api/meetings", methods=["POST"])
@require_auth
def create_meeting():
    data = request.get_json() or {}
    mentor_id    = data.get("mentor_id")
    session_type = (data.get("session_type") or "").strip()
    date         = (data.get("date") or "").strip()
    time         = (data.get("time") or "").strip()
    notes        = (data.get("notes") or "").strip()

    if not session_type or not date or not time:
        return jsonify({"error": "session_type, date, and time are required"}), 422

    db = get_db()
    cur = db.execute(
        "INSERT INTO meetings (user_id,mentor_id,session_type,date,time,notes) VALUES (?,?,?,?,?,?)",
        (g.user_id, mentor_id, session_type, date, time, notes)
    )
    db.commit()
    row = row_to_dict(db.execute("""
        SELECT m.*, mt.name AS mentor_name, mt.emoji AS mentor_emoji
        FROM meetings m LEFT JOIN mentors mt ON mt.id = m.mentor_id
        WHERE m.id=?
    """, (cur.lastrowid,)).fetchone())
    return jsonify(row), 201


@app.route("/api/meetings/<int:mid>", methods=["PATCH"])
@require_auth
def update_meeting(mid):
    db = get_db()
    meeting = row_to_dict(db.execute("SELECT * FROM meetings WHERE id=? AND user_id=?", (mid, g.user_id)).fetchone())
    if not meeting:
        return jsonify({"error": "Not found"}), 404
    data = request.get_json() or {}
    allowed = ["session_type", "date", "time", "notes", "status"]
    sets, vals = [], []
    for k in allowed:
        if k in data:
            sets.append(f"{k}=?")
            vals.append(data[k])
    if sets:
        vals.append(mid)
        db.execute(f"UPDATE meetings SET {','.join(sets)} WHERE id=?", vals)
        db.commit()
    return jsonify(row_to_dict(db.execute("SELECT * FROM meetings WHERE id=?", (mid,)).fetchone()))


@app.route("/api/meetings/<int:mid>", methods=["DELETE"])
@require_auth
def delete_meeting(mid):
    db = get_db()
    db.execute("DELETE FROM meetings WHERE id=? AND user_id=?", (mid, g.user_id))
    db.commit()
    return jsonify({"deleted": mid})


# ─────────────────────────────────────────────
# LESSONS CATALOG
# ─────────────────────────────────────────────
@app.route("/api/lessons", methods=["GET"])
def get_lessons():
    db = get_db()
    return jsonify(rows_to_list(db.execute("SELECT * FROM lessons ORDER BY module_num").fetchall()))


# ─────────────────────────────────────────────
# USER LESSONS
# ─────────────────────────────────────────────
@app.route("/api/user-lessons", methods=["GET"])
@require_auth
def get_user_lessons():
    db = get_db()
    rows = db.execute("""
        SELECT ul.*, l.title, l.description, l.duration_min, l.level, l.emoji, l.module_num
        FROM user_lessons ul
        JOIN lessons l ON l.id = ul.lesson_id
        WHERE ul.user_id = ?
        ORDER BY ul.created_at DESC
    """, (g.user_id,)).fetchall()
    return jsonify(rows_to_list(rows))


@app.route("/api/user-lessons", methods=["POST"])
@require_auth
def add_user_lesson():
    data = request.get_json() or {}
    lesson_id   = data.get("lesson_id")
    members_tag = data.get("members_tag", "Whole Family")
    date        = data.get("date", "")
    time_slot   = data.get("time_slot", "")

    if not lesson_id:
        return jsonify({"error": "lesson_id required"}), 422

    db = get_db()
    # Check lesson exists
    if not db.execute("SELECT id FROM lessons WHERE id=?", (lesson_id,)).fetchone():
        return jsonify({"error": "Lesson not found"}), 404

    cur = db.execute(
        "INSERT INTO user_lessons (user_id,lesson_id,members_tag,date,time_slot) VALUES (?,?,?,?,?)",
        (g.user_id, lesson_id, members_tag, date, time_slot)
    )
    db.commit()
    row = row_to_dict(db.execute("""
        SELECT ul.*, l.title, l.description, l.duration_min, l.level, l.emoji, l.module_num
        FROM user_lessons ul JOIN lessons l ON l.id = ul.lesson_id
        WHERE ul.id=?
    """, (cur.lastrowid,)).fetchone())
    return jsonify(row), 201


@app.route("/api/user-lessons/<int:ulid>", methods=["PATCH"])
@require_auth
def update_user_lesson(ulid):
    db = get_db()
    ul = row_to_dict(db.execute("SELECT * FROM user_lessons WHERE id=? AND user_id=?", (ulid, g.user_id)).fetchone())
    if not ul:
        return jsonify({"error": "Not found"}), 404
    data = request.get_json() or {}
    allowed = ["progress", "status", "date", "time_slot", "members_tag"]
    sets, vals = [], []
    for k in allowed:
        if k in data:
            sets.append(f"{k}=?")
            vals.append(data[k])
    if sets:
        vals.append(ulid)
        db.execute(f"UPDATE user_lessons SET {','.join(sets)} WHERE id=?", vals)
        db.commit()
    return jsonify(row_to_dict(db.execute("SELECT * FROM user_lessons WHERE id=?", (ulid,)).fetchone()))


@app.route("/api/user-lessons/<int:ulid>", methods=["DELETE"])
@require_auth
def delete_user_lesson(ulid):
    db = get_db()
    db.execute("DELETE FROM user_lessons WHERE id=? AND user_id=?", (ulid, g.user_id))
    db.commit()
    return jsonify({"deleted": ulid})


# ─────────────────────────────────────────────
# FAMILY MEMBERS
# ─────────────────────────────────────────────
@app.route("/api/family-members", methods=["GET"])
@require_auth
def get_family_members():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM family_members WHERE user_id=? ORDER BY created_at",
        (g.user_id,)
    ).fetchall()
    return jsonify(rows_to_list(rows))


@app.route("/api/family-members", methods=["POST"])
@require_auth
def add_family_member():
    data = request.get_json() or {}
    name         = (data.get("name") or "").strip()
    age          = data.get("age")
    relationship = (data.get("relationship") or "").strip()
    email        = (data.get("email") or "").strip()

    if not name or not relationship:
        return jsonify({"error": "name and relationship required"}), 422

    db = get_db()
    cur = db.execute(
        "INSERT INTO family_members (user_id,name,age,relationship,email) VALUES (?,?,?,?,?)",
        (g.user_id, name, age, relationship, email)
    )
    db.commit()
    return jsonify(row_to_dict(db.execute("SELECT * FROM family_members WHERE id=?", (cur.lastrowid,)).fetchone())), 201


@app.route("/api/family-members/<int:fid>", methods=["DELETE"])
@require_auth
def delete_family_member(fid):
    db = get_db()
    db.execute("DELETE FROM family_members WHERE id=? AND user_id=?", (fid, g.user_id))
    db.commit()
    return jsonify({"deleted": fid})


# ─────────────────────────────────────────────
# DASHBOARD SUMMARY
# ─────────────────────────────────────────────
@app.route("/api/dashboard", methods=["GET"])
@require_auth
def dashboard():
    db = get_db()
    today = datetime.now().strftime("%Y-%m-%d")

    upcoming = db.execute(
        "SELECT COUNT(*) AS c FROM meetings WHERE user_id=? AND date >= ? AND status='scheduled'",
        (g.user_id, today)
    ).fetchone()["c"]

    completed_lessons = db.execute(
        "SELECT COUNT(*) AS c FROM user_lessons WHERE user_id=? AND status='completed'",
        (g.user_id,)
    ).fetchone()["c"]

    members = db.execute(
        "SELECT COUNT(*) AS c FROM family_members WHERE user_id=?",
        (g.user_id,)
    ).fetchone()["c"]

    next_meeting = row_to_dict(db.execute("""
        SELECT m.*, mt.name AS mentor_name, mt.emoji AS mentor_emoji
        FROM meetings m LEFT JOIN mentors mt ON mt.id = m.mentor_id
        WHERE m.user_id=? AND m.date >= ? AND m.status='scheduled'
        ORDER BY m.date, m.time LIMIT 1
    """, (g.user_id, today)).fetchone())

    return jsonify({
        "upcoming_meetings": upcoming,
        "completed_lessons": completed_lessons,
        "family_members": members,
        "next_meeting": next_meeting,
    })


# ─────────────────────────────────────────────
# HEALTH CHECK
# ─────────────────────────────────────────────
@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "FamilyBridge API", "version": "1.0.0"})


# ─────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    print(f"🚀 FamilyBridge API running on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
