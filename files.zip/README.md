# 🌿 FamilyBridge — Full-Stack Application

A psychology-focused family relationship platform connecting parents and children with certified mentors.

---

## Project Structure

```
familybridge/
├── backend/
│   └── app.py              # Flask REST API + SQLite database
└── frontend/
    └── index.html          # Single-file HTML/CSS/JS frontend
```

---

## Backend Setup

### Requirements
- Python 3.8+
- Flask (`pip install flask`)
- PyJWT (`pip install pyjwt`)

### Run the API server
```bash
cd backend
python app.py
```
The API will start at **http://localhost:5000**

On first run it will:
- Create `familybridge.db` (SQLite)
- Seed 3 mentor profiles
- Seed 8 lesson modules

---

## Frontend Setup

Open `frontend/index.html` in your browser — no build step required.

> Make sure the backend is running at `http://localhost:5000` before using the app.

---

## API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login, returns JWT |
| GET | `/api/auth/me` | Get current user (auth required) |

### Mentors & Lessons (public)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/mentors` | List all mentors |
| GET | `/api/lessons` | List all lesson modules |

### Meetings (auth required)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/meetings` | List user's meetings |
| POST | `/api/meetings` | Book a new meeting |
| PATCH | `/api/meetings/:id` | Update meeting |
| DELETE | `/api/meetings/:id` | Cancel meeting |

### User Lessons (auth required)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/user-lessons` | List enrolled lessons |
| POST | `/api/user-lessons` | Add a lesson to plan |
| PATCH | `/api/user-lessons/:id` | Update progress/status |
| DELETE | `/api/user-lessons/:id` | Remove lesson |

### Family Members (auth required)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/family-members` | List family members |
| POST | `/api/family-members` | Add a member |
| DELETE | `/api/family-members/:id` | Remove a member |

### Dashboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard` | KPI summary for current user |

---

## Features

- **JWT Authentication** — Secure login & registration
- **Session persistence** — Token stored in localStorage, auto-restored on reload
- **Book meetings** — Schedule with any mentor, pick date/time, add notes
- **Manage lessons** — Add modules from 8-lesson catalog, track progress, mark complete
- **Family members** — Add/remove family members with relationships and ages
- **Interactive calendar** — Visual month view with event dots; click to schedule
- **Dashboard KPIs** — Live stats for meetings, lessons, and family size
- **Full CRUD** — Delete meetings, lessons, and family members in real time

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python · Flask · SQLite |
| Auth | JWT (PyJWT) |
| Frontend | Vanilla HTML/CSS/JS |
| Fonts | Cormorant Garamond · DM Sans |
| Styling | CSS custom properties · CSS animations |
